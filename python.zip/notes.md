- prioritize miners early to take up spots done?
- will there always be sufficient funds to buy a cart at the start of the game
- cart assignments

- intelligent miner algorithm that actually takes into account the rate at which we're producing blitzium and the distance we need to carry it and not just random heuristics
- cart paths
